-- ====================================================================================================================
-- lua package v0.2 for planetwars challenge by barabanus (buratin.barabanus@gmail.com), 2010-09-24
-- originally written by ridcully (robert.brandner@gmail.com), 2010-09-14
-- ====================================================================================================================

function do_turn()
	local target = notmy_planets()
	for i, p in ipairs(my_planets()) do
		local dst = target[math.random(#target)]
		issue_order(p.id, dst.id, p.ships/2)
	end	
end

dofile "planetwars.lua"

-- ====================================================================================================================