-- ====================================================================================================================
-- lua package v0.2 for planetwars challenge by barabanus (buratin.barabanus@gmail.com), 2010-09-24
-- originally written by ridcully (robert.brandner@gmail.com), 2010-09-14
-- ====================================================================================================================

NEUTRAL, MINE, ENEMY = 0, 1, 2

-- game state
local pw = { turn = 0 }

local function reset_state()
	pw = {
		planets = {}, fleets = {}, 
		my_planets = {}, enemy_planets = {}, neutral_planets = {}, notmy_planets = {},
		my_fleets = {}, enemy_fleets = {},
		turn = pw.turn + 1
	}
end

reset_state()

-- ====================================================================================================================

-- debug issue
function trace (format, ...)
	io.stderr:write(format:format(...), "\n")
	io.stderr:flush()
end

-- ====================================================================================================================

function turn()				return pw.turn				end

function planets()			return pw.planets 			end
function get_planet(id)		return pw.planets[id+1]		end

function my_planets()		return pw.my_planets		end
function neutral_planets()	return pw.neutral_planets 	end
function enemy_planets()	return pw.enemy_planets 	end
function notmy_planets()	return pw.notmy_planets		end

function fleets()			return pw.fleets			end
function my_fleets()		return pw.my_fleets 		end
function enemy_fleets()		return pw.enemy_fleets 		end

function distance (src_id, dst_id)
	local dx = pw.planets[src_id+1].x - pw.planets[dst_id+1].x 
	local dy = pw.planets[src_id+1].y - pw.planets[dst_id+1].y
	return math.ceil(math.sqrt(dx * dx + dy * dy))
end

-- ====================================================================================================================

function issue_order (src_id, dest_id, ships)
	ships = math.floor(ships)
	io.write(src_id, " ", dest_id, " ", ships, "\n")
	io.flush()
end

-- ====================================================================================================================

local function finish_turn()
	io.write("go\n")
	io.flush()
end

-- ====================================================================================================================

local pid = 0									-- planet ids start from 0 (normally, Lua indices start from 1)
local fid = 0 									-- fleet "ids" start from 0
while true do
	local line = io.read()
	if line == nil then break end
	line = string.gsub(line, "#.*", "")			-- strip comments from line
	if line == 'go' then
		do_turn()
		finish_turn()
		reset_state()
		pid = 0
	else
		if string.find(line, "P") == 1 then		-- planet
			local a, b, c, d, e = string.match(line, "P (%d+%.%d+) (%d+%.%d+) (%d+) (%d+) (%d+)")
			local p = {id = pid, x = tonumber(a), y = tonumber(b), owner = tonumber(c), ships = tonumber(d), growth = tonumber(e)}
			
			table.insert(pw.planets, p)
			if p.owner == MINE then 
				table.insert(pw.my_planets, p)
			else
				table.insert(pw.notmy_planets, p)
				if p.owner == ENEMY 
					then table.insert(pw.enemy_planets, p)
					else table.insert(pw.neutral_planets, p)
				end
			end
			
			pid = pid + 1
			
		elseif string.find(line, "F") == 1 then	-- fleet
			local a, b, c, d, e, f = string.match(line, "F (%d+) (%d+) (%d+) (%d+) (%d+) (%d+)")
			local f = { id = fid, owner = tonumber(a), ships = tonumber(b), source = tonumber(c), dest = tonumber(d), total_trip_length = tonumber(e), turns_remaining = tonumber(f) }
			
			table.insert(pw.fleets, f)
			if f.owner == MINE
				then table.insert(pw.my_fleets, f)
				else table.insert(pw.enemy_fleets, f)
			end
			
			fid = fid + 1
		end
	end
end

-- ====================================================================================================================