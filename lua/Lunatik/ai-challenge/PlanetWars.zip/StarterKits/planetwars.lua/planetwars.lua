--
-- Lua starter package (Java required) version 1.0
-- written by ridcully (robert.brandner@gmail.com), 2010-09-14
-- 
-- Usage: 
-- Get yourself the Java-Starter Package first. Put this file into the base directory of the Java starter package.
-- In the shell:
-- cd <base directory of Java starter package>
-- java -jar tools/PlayGame.jar maps/map7.txt 1000 1000 log.txt "lua planetwars.lua" "java -jar example_bots/BullyBot.jar" | java -jar tools/ShowGame.jar
--

-- constants for clarity
local OWNER_NEUTRAL = 0
local OWNER_ME = 1
local OWNER_ENEMY = 2

-- game state
local pw = {planets = {}, fleets = {}}

local function num_planets()
	-- Returns the number of planets. Planets are numbered starting with 0.
	return #pw.planets+1
end

local function get_planet(id)
	-- Returns the planet with the given planet_id. There are NumPlanets() planets. They are numbered starting at 0.
	return pw.planets[id]
end

local function num_fleets()
	-- Returns the number of fleets.
	return #pw.fleets+1
end

local function get_fleet(id)
	-- Returns the fleet with the given fleet_id. Fleets are numbered starting with 0. There are NumFleets() fleets. 
	-- fleet_id's are not consistent from one turn to the next.
	return pw.fleets[id]
end

local function planets()
	-- Returns a list of all the planets.
	return pw.planets
end

local function _elements_by_owner(list, owner)
	-- helper function, can be used for planets and fleets
	local result = {}
	for _, e in pairs(list)  do
		if e.owner == owner then result[#result+1] = e end
	end
	return result
end

local function my_planets()
	-- Return a list of all the planets owned by the current player. By
	-- convention, the current player is always player number 1. 
	return _elements_by_owner(pw.planets, OWNER_ME)
end

local function neutral_planets()
	-- Return a list of all neutral planets.
	return _elements_by_owner(pw.planets, OWNER_NEUTRAL)
end

local function enemy_planets()
	-- Return a list of all the planets owned by rival players. This excludes
	-- planets owned by the current player, as well as neutral planets.
	return _elements_by_owner(pw.planets, OWNER_ENEMY)
end

local function not_my_planets()
	-- Return a list of all the planets that are not owned by the current
	-- player. This includes all enemy planets and neutral planets.
	local result = {}
	for _, e in pairs(pw.planets)  do
		if e.owner ~= OWNER_ME then result[#result+1] = e end
	end
	return result
end

local function fleets()
	-- Return a list of all the fleets.
	return pw.fleets
end

local function my_fleets()
	--  Return a list of all the fleets owned by the current player.
	return _elements_by_owner(pw.fleets, OWNER_ME)
end

local function enemy_fleets()
	-- Return a list of all the fleets owned by enemy players.
	return _elements_by_owner(pw.fleets, OWNER_ENEMY)
end

local function distance(source_id, dest_id)
	-- Returns the distance between two planets, rounded up to the next highest nteger. 
	-- This is the number of discrete time steps it takes to get between the two planets.
	local dx = pw.planets[source_id].x - pw.planets[dest_id].x 
	local dy = pw.planets[source_id].y - pw.planets[dest_id].y
	return math.ceil(math.sqrt(dx * dx + dy * dy))
end

local function issue_order(source_id, dest_id, ships)
	-- Sends an order to the game engine. An order is composed of a source planet number, a destination planet number, and a number of ships.
	-- A few things to keep in mind:
	-- * you can issue many orders per turn if you like.
	-- * the planets are numbered starting at zero, not one.
	-- * you must own the source planet. If you break this rule, the game engine kicks your bot out of the game instantly.
	-- * you can't move more ships than are currently on the source planet.
	-- * the ships will take a few turns to reach their destination. Travel is not instant. See the distance() function for more info.
	ships = math.floor(ships)	-- ensure safe integer value
	io.write(source_id, " ", dest_id, " ", ships, "\n")
	io.flush()
end

local function finish_turn()
	-- Sends the game engine a message to let it know that we're done sending orders. This signifies the end of our turn.
	io.write("go\n")
	io.flush()
end

-- don't change anything above ------------------------------------------------------------------------------------------------

local function do_turn()
	-- this is, where your code goes.
	-- test bot ... find own planet and send half of the ships to random other planet
	for _, p in pairs(pw.planets) do
		if p.owner == OWNER_ME then
			dest_id = math.floor(math.random() * #pw.planets)
			issue_order(p.id, dest_id, p.ships/2)
			return
		end
	end	
end

-- don't change anything below ------------------------------------------------------------------------------------------------

--
-- main loop (including all the parsing and creation of 'objects')
--
local pid = 0									-- planet ids start from 0 (normally, Lua indices start from 1)
local fid = 0 									-- fleet "ids" start from 0
while true do
	local line = io.read()
	if line == nil then break end
	line = string.gsub(line, "#.*", "")				-- strip comments from line
	if line == 'go' then
		do_turn()
		finish_turn()
		pw = {planets = {}, fleets = {}}			-- reset state
		pid = 0
	else
		if string.find(line, "P") == 1 then			-- planet
			local a, b, c, d, e = string.match(line, "P (%d+%.%d+) (%d+%.%d+) (%d+) (%d+) (%d+)")
			pw.planets[pid] = {id = pid, x = tonumber(a), y = tonumber(b), owner = tonumber(c), ships = tonumber(d), growth = tonumber(e)}
			pid = pid + 1
		elseif string.find(line, "F") == 1 then	-- fleet
			local a, b, c, d, e, f = string.match(line, "F (%d+) (%d+) (%d+) (%d+) (%d+) (%d+)")
			pw.fleets[fid] = {id = fid, owner = tonumber(a), ships = tonumber(b), source = tonumber(c), dest = tonumber(d), total_trip_length = tonumber(e), turns_remaining = tonumber(f)}
			fid = fid + 1
		end
	end
end
